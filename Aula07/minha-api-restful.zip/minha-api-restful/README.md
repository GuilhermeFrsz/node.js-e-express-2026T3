# API de Gerenciamento de Produtos

Esta é uma API RESTful desenvolvida em Node.js e Express para gerenciar um catálogo de produtos em memória.

## 🚀 Como rodar o projeto

1. Certifique-se de ter o Node.js instalado.
2. Clone este repositório ou baixe os arquivos.
3. Instale as dependências:
```bash
npm install
```

4. Inicie o servidor:
```bash
node --watch server.js
```
O servidor rodará em `http://localhost:3000`.

## 📌 Endpoints da API

### `GET /products`
Retorna a lista de todos os produtos.

### `GET /products/:id`
Retorna os detalhes de um produto específico pelo ID.

### `POST /products`
Cria um novo produto. 

**Body esperado (JSON):**
```json
{
  "nome": "Mouse Gamer",
  "preco": 150,
  "estoque": 10,
  "categoria": "Eletrônicos"
}
```

### `PUT /products/:id` ou `PATCH /products/:id`
Atualiza os dados de um produto existente. O PATCH é recomendado para atualizações parciais (enviar apenas o que deseja mudar).

### `DELETE /products/:id`
Remove um produto do catálogo pelo ID.